# featured-image-resizer

Simple plugin to set the featured image size to a wordpress media size by default.  Handy if your authors forget to set this on upload.

NOTE:  You will need to edit a php file to get this plugin to work.  If you are not comfortable editing php files, please consult a developer.  No free support is offered for this plugin.

To use:

Download the zip file

Open the featured-image-resizer.php file in a text editor.

edit line 25, changing 'featured-iamge' with your wordpress media size.

save and upload the plugin

Activate the plugin.
